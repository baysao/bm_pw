<?php
namespace Piwik\Plugins\QualityAssurance\Reports;

use Piwik\Metrics;

abstract class Base extends \Piwik\Plugin\Report
{
    protected function init()
    {

    }
}